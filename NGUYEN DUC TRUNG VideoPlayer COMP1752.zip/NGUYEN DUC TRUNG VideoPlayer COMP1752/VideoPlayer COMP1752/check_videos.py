import tkinter as tk  # Import the tkinter library under alias tk
import tkinter.scrolledtext as tkst  # Import the scrolledtext submodule from tkinter
from PIL import Image, ImageTk  # Import Image and ImageTk from the PIL library

import video_library as lib # Import custom module video_library as lib
import font_manager as fonts # Import custom module font_manager as fonts

def set_text(text_area, content): # Insert text of the main window
    text_area.delete("1.0", tk.END) # Clear existing content in text area
    text_area.insert(1.0, content) # Insert new content at the beginning of text area

class CheckVideos(): # Class representing the Check Videos, which is used to call function from 'check_videos_clicked' in video_player.py
    def __init__(self, window): # Insert GUI window main application

        window.geometry("1100x350")  # Set main window size
        window.title("Check Videos")  # Title for main video

        list_videos_btn = tk.Button(window, text="List All Videos", command=self.list_videos_clicked) # Insert 'List All Videos' button
        list_videos_btn.grid(row=0, column=0, padx=10, pady=10) # Set coordination

        enter_lbl = tk.Label(window, text="Enter Video Number") # Insert 'Enter Video Number' label
        enter_lbl.grid(row=0, column=1, padx=10, pady=10)

        self.input_txt = tk.Entry(window, width=3) # Insert entry widget for video numbers input
        self.input_txt.grid(row=0, column=2, padx=10, pady=10)

        check_video_btn = tk.Button(window, text="Check Video", command=self.check_video_clicked) # Insert 'Check Video' button
        check_video_btn.grid(row=0, column=3, padx=10, pady=10)

        self.list_txt = tkst.ScrolledText(window, width=48, height=12, wrap="none") # Insert ScrolledText widget for list all video
        self.list_txt.grid(row=1, column=0, columnspan=3, sticky="W", padx=10, pady=10)

        self.video_txt = tk.Text(window, width=24, height=4, wrap="none") # Insert text widget to display specific video details
        self.video_txt.grid(row=1, column=3, sticky="NW", padx=10, pady=10)
        set_text(self.video_txt,"Please enter a video number")

        self.image_lbl = tk.Label(window) # Label for displaying the video image
        self.image_lbl.grid(row=1, column=4, sticky="NW", padx=10, pady=10)

        self.status_lbl = tk.Label(window, text="", font=("Helvetica", 10)) # Insert label prompting the user for status
        self.status_lbl.grid(row=2, column=0, columnspan=4, sticky="W", padx=10, pady=10)

        self.list_videos_clicked() # Call method to list all video initially

    def check_video_clicked(self):  # Handle the 'Check Video' button click
        key = self.input_txt.get()  # Get video number from input entry widget
        name = lib.get_name(key)  # Retrieve video name from library by the corresponding number

        # Map video numbers to image filenames
        image_map = {
            '01': 'TomandJerry.jpg',
            '02': 'BreakfastAtTiffanys.jpg',
            '03': 'Casablanca.jpg',
            '04': 'TheSoundOfMusic.jpg',
            '05': 'GoneWithTheWind.jpg',
            'not_found': 'VideoNotFound.jpg'  # Image to show if video is not found
        }

        if name is not None:  # If video name is found in the library
            director = lib.get_director(key)  # Get director of the video
            rating = lib.get_rating(key)  # Get rating of the video
            play_count = lib.get_play_count(key)  # Get play count of the video
            video_details = f"{name}\n{director}\nrating: {rating}\nplays: {play_count}"
            set_text(self.video_txt, video_details)  # Display video details in the text widget

            # Get the image filename based on the video number
            image_filename = image_map.get(key, image_map['not_found'])

        else:  # If video name is not found
            video_details = f"Video {key} not found"
            set_text(self.video_txt, video_details)  # Display error message
            image_filename = image_map['not_found']  # Use 'VideoNotFound' image

        # Load and display the appropriate image
        image_path = f"C:\\Users\\Admin\\Downloads\\VideoPlayer COMP1752\\VideoPlayer COMP1752\\video_image_display\\{image_filename}"
        try:
            image = Image.open(image_path)
            photo = ImageTk.PhotoImage(image)
            self.image_lbl.config(image=photo)
            self.image_lbl.image = photo  # Keep a reference to avoid garbage collection
        except:
            self.image_lbl.config(image='', text='')  # Clear the label if image fails to load

        self.status_lbl.configure(text="Check Video button was clicked!")

    def list_videos_clicked(
            self):  # Insert a method that retrieves and displays a list of all available videos in the library
        video_list = lib.list_all()  # Get list of all videos from the library using the provided function in video_library.py
        set_text(self.list_txt, video_list)  # Display list of videos in the scrolled text widget
        self.status_lbl.configure(text="List Videos button was clicked!")

if __name__ == "__main__":  # only runs when this file is run as a standalone
    window = tk.Tk()        # create a TK object
    fonts.configure()       # configure the fonts
    CheckVideos(window)     # open the CheckVideo GUI
    window.mainloop()       # run the window main loop, reacting to button presses, etc
