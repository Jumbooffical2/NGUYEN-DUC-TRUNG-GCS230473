class LibraryItem:
    def __init__(self, name, director, rating, play_count=0):
        self.name = name
        self.director = director
        self.rating = int(rating)  # Ensure rating is an integer
        self.play_count = play_count  # Initialize play_count

    def info(self):
        return f"{self.name} - {self.director} {self.stars()}"

    def stars(self):
        return '☆' * self.rating  # Efficiently generate stars for rating

    def increment_play_count(self):
        self.play_count += 1  # Increment the play count
