import csv
from library_item import LibraryItem

CSV_FILE = 'video_library.csv'

library = {}
playlist = []

def read_video_library():
    global library
    try:
        with open(CSV_FILE, mode='r', newline='') as file:
            reader = csv.reader(file)
            library = {row[0]: LibraryItem(row[1], row[2], int(row[3]), int(row[4])) for row in reader}
    except FileNotFoundError:
        library["01"] = LibraryItem("Tom and Jerry", "Fred Quimby", 4)
        library["02"] = LibraryItem("Breakfast at Tiffany's", "Blake Edwards", 5)
        library["03"] = LibraryItem("Casablanca", "Michael Curtiz", 2)
        library["04"] = LibraryItem("The Sound of Music", "Robert Wise", 1)
        library["05"] = LibraryItem("Gone with the Wind", "Victor Fleming", 3)
        write_video_library()

def write_video_library():
    try:
        with open(CSV_FILE, mode='w', newline='') as file:
            writer = csv.writer(file)
            for key, item in library.items():
                writer.writerow([key, item.name, item.director, item.rating, item.play_count])
    except IOError as e:
        print(f"Error writing to {CSV_FILE}: {e}")

def list_all():
    output = ""
    for key, item in library.items():
        output += f"{key} {item.info()}\n"
    return output

def get_name(key):
    return library.get(key).name if key in library else None

def get_director(key):
    return library.get(key).director if key in library else None

def get_rating(key):
    return library.get(key).rating if key in library else -1

def set_rating(key, rating):
    if key in library:
        try:
            rating = int(rating)
            if 1 <= rating <= 5:
                library[key].rating = rating
            else:
                print(f"Invalid rating value: {rating}. Rating must be between 1 and 5.")
        except ValueError:
            print(f"Invalid rating value: {rating}. Rating must be an integer.")

def get_play_count(key):
    return library.get(key).play_count if key in library else -1

def increment_play_count(key):
    if key in library:
        library[key].increment_play_count()

def is_valid_video_number(number):
    if number.isdigit() and len(number) == 2:
        return True
    return False

read_video_library()
