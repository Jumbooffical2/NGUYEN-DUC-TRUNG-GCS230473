import tkinter as tk
from tkinter import messagebox
from check_videos import CheckVideos
import font_manager as fonts
import video_library as lib

class Video:
    def __init__(self, number, name, play_count=0):
        self.number = number
        self.name = name
        self.play_count = play_count

    def increment_play_count(self):
        self.play_count += 1

def set_text(text_area, content):
    text_area.delete("1.0", tk.END)
    text_area.insert(tk.END, content)

def check_videos_clicked():
    status_lbl.configure(text="Check Videos button was clicked!")
    CheckVideos(tk.Toplevel(window))
    apply_mode_to_window(window)

def create_video_list_clicked():
    status_lbl.configure(text="Create Video List button was clicked!")

    list_window = tk.Toplevel(window)
    list_window.geometry("400x600")
    list_window.title("Create Your Video List")
    apply_mode_to_window(list_window)

    enter_lbl = tk.Label(list_window, text="Enter Video Number")
    enter_lbl.grid(row=0, column=3, padx=10, pady=10)

    input_txt = tk.Entry(list_window, width=3)
    input_txt.grid(row=1, column=3, padx=10, pady=10)

    add_video_btn = tk.Button(list_window, text="Add Video", command=lambda: add_video(input_txt, playlist_txt))
    add_video_btn.grid(row=2, column=3, padx=10, pady=10)

    available_lbl = tk.Label(list_window, text="[Available Videos]")
    available_lbl.grid(row=3, column=3, padx=10, pady=10)
    video_txt = tk.Text(list_window, width=40, height=5, wrap="none")
    video_txt.grid(row=4, column=3, padx=10, pady=10)
    video_list = lib.list_all()
    set_text(video_txt, video_list)

    global playlist_txt
    playlist_lbl = tk.Label(list_window, text="[Your Playlist]")
    playlist_lbl.grid(row=5, column=3, padx=10, pady=10)
    playlist_txt = tk.Text(list_window, width=40, height=5, wrap="none")
    playlist_txt.grid(row=6, column=3, padx=10, pady=10)

    play_playlist_btn = tk.Button(list_window, text="Play Playlist", command=play_playlist)
    play_playlist_btn.grid(row=7, column=3, padx=10, pady=10)

    reset_playlist_btn = tk.Button(list_window, text="Reset Playlist", command=reset_playlist)
    reset_playlist_btn.grid(row=8, column=3, padx=10, pady=10)

def add_video(input_txt, playlist_txt):
    video_number = input_txt.get().strip()
    if not video_number.isdigit() or len(video_number) != 2:
        messagebox.showerror("Invalid Input", "The video number must be a two-digit integer.")
        return

    if video_number not in lib.library:
        messagebox.showerror("Invalid Video Number", "The video number is not valid.")
        return

    video_name = lib.get_name(video_number)
    if video_name is None:
        messagebox.showerror("Invalid Video Number", "The video number is not valid.")
        return

    existing_videos = [item.name for item in lib.playlist]
    if video_name in existing_videos:
        messagebox.showinfo("Video Already Added", f"The video '{video_name}' is already in the playlist.")
        return

    video = Video(video_number, video_name)
    lib.playlist.append(video)
    update_playlist_display()

def update_playlist_display():
    playlist_txt.delete(1.0, tk.END)
    for video in lib.playlist:
        playlist_txt.insert(tk.END, f"{video.number}: {video.name}\n")

def play_playlist():
    for video in lib.playlist:
        lib.increment_play_count(video.number)
        video.increment_play_count()
    messagebox.showinfo("Playlist Played", "The playlist has been played. Each video’s play count has been incremented.")
    lib.write_video_library()

def reset_playlist():
    lib.playlist = []
    update_playlist_display()

def update_video_clicked():
    status_lbl.configure(text="Update Video button was clicked!")

    update_window = tk.Toplevel(window)
    update_window.geometry("400x420")
    update_window.title("Update Video Rating")
    apply_mode_to_window(update_window)

    lbl_video_number = tk.Label(update_window, text="Video Number:")
    lbl_video_number.grid(row=0, column=3, padx=10, pady=10)
    entry_video_number = tk.Entry(update_window, width=3)
    entry_video_number.grid(row=1, column=3, padx=10, pady=10)

    lbl_new_rating = tk.Label(update_window, text="New Rating:")
    lbl_new_rating.grid(row=2, column=3, padx=10, pady=10)
    entry_new_rating = tk.Entry(update_window, width=3)
    entry_new_rating.grid(row=3, column=3, padx=10, pady=10)

    def update_rating():
        video_number = entry_video_number.get().strip()
        new_rating = entry_new_rating.get().strip()

        if not video_number.isdigit() or len(video_number) != 2:
            messagebox.showerror("Invalid Input", "The video number must be a two-digit integer.")
            return

        if video_number not in lib.library:
            messagebox.showerror("Invalid Video Number", "The video number is not valid.")
            return

        try:
            new_rating = int(new_rating)
            if new_rating < 1 or new_rating > 5:
                messagebox.showerror("Invalid Rating", "The rating must be between 1 and 5.")
                return
        except ValueError:
            messagebox.showerror("Invalid Rating", "The rating must be an integer between 1 and 5.")
            return

        lib.set_rating(video_number, new_rating)
        play_count = lib.get_play_count(video_number)
        video_name = lib.get_name(video_number)
        messagebox.showinfo("Rating Updated", f"Video: {video_name}\nNew Rating: {new_rating}\nPlay Count: {play_count}")
        lib.write_video_library()

    btn_update = tk.Button(update_window, text="Update Rating", command=update_rating)
    btn_update.grid(row=4, column=3, padx=10, pady=10)

    available_lbl = tk.Label(update_window, text="[Available Videos]")
    available_lbl.grid(row=5, column=3, padx=10, pady=10)
    video_txt = tk.Text(update_window, width=40, height=5, wrap="none")
    video_txt.grid(row=6, column=3, padx=10, pady=10)
    video_list = lib.list_all()
    set_text(video_txt, video_list)

def apply_dark_mode(widget):
    widget.configure(bg="#2e2e2e")
    for child in widget.winfo_children():
        if isinstance(child, tk.Label) or isinstance(child, tk.Text):
            child.configure(bg="#2e2e2e", fg="#ffffff")
        elif isinstance(child, tk.Button) or isinstance(child, tk.Checkbutton):
            child.configure(bg="#555555", fg="#ffffff")
        if child.winfo_children():
            apply_dark_mode(child)

def apply_light_mode(widget):
    widget.configure(bg="#ffffff")
    for child in widget.winfo_children():
        if isinstance(child, tk.Label) or isinstance(child, tk.Text):
            child.configure(bg="#ffffff", fg="#000000")
        elif isinstance(child, tk.Button) or isinstance(child, tk.Checkbutton):
            child.configure(bg="#e0e0e0", fg="#000000")
        if child.winfo_children():
            apply_light_mode(child)

def toggle_dark_mode():
    if dark_mode_var.get():
        apply_dark_mode(window)
    else:
        apply_light_mode(window)
    window.dark_mode_enabled = dark_mode_var.get()

def apply_mode_to_window(widget):
    if getattr(window, 'dark_mode_enabled', False):
        apply_dark_mode(widget)
    else:
        apply_light_mode(widget)

def settings_clicked():
    status_lbl.configure(text="Settings button was clicked!")

    list_window = tk.Toplevel(window)
    list_window.geometry("400x520")
    list_window.title("Settings")

    global dark_mode_var
    dark_mode_var = tk.BooleanVar()
    dark_mode_var.set(getattr(window, 'dark_mode_enabled', False))

    dark_mode_btn = tk.Checkbutton(list_window, text="Dark Mode", variable=dark_mode_var, command=toggle_dark_mode)
    dark_mode_btn.grid(row=0, column=3, padx=10, pady=10)

    toggle_dark_mode()

window = tk.Tk()
window.geometry("680x150")
window.title("Video Player")

window.dark_mode_enabled = False

fonts.configure()

header_lbl = tk.Label(window, text="Select an option by clicking one of the buttons below")
header_lbl.grid(row=0, column=0, columnspan=3, padx=10, pady=10)

check_videos_btn = tk.Button(window, text="Check Videos 🔍", command=check_videos_clicked)
check_videos_btn.grid(row=1, column=0, padx=10, pady=10)

create_video_list_btn = tk.Button(window, text="Create Video List 📝", command=create_video_list_clicked)
create_video_list_btn.grid(row=1, column=1, padx=10, pady=10)

update_videos_btn = tk.Button(window, text="Update Videos  ☆", command=update_video_clicked)
update_videos_btn.grid(row=1, column=2, padx=10, pady=10)

settings_btn = tk.Button(window, text="⚙️", command=settings_clicked)
settings_btn.grid(row=1, column=3, padx=10, pady=10)

status_lbl = tk.Label(window, text="", font=("Helvetica", 10))
status_lbl.grid(row=2, column=0, columnspan=3, padx=10, pady=10)

window.mainloop()
